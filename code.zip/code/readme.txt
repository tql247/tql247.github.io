If you already have all necessary requirement package, run file Ontology.py. Please install all packages following first, if not.

package:
	- re
	- numpy
	- pandas
	- pyvi
	- const
	- sklearn